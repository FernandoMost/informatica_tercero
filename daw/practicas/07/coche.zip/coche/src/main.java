class main {
    public static void main(String [] args) {
        coche.CarBean miCoche=new coche.CarBean();
        System.out.println("Mi coche es un " + miCoche.getFabricante());
    }
}
