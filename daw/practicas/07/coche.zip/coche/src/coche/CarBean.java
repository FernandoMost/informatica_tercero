package coche;

import java.io.Serializable;

public class CarBean implements Serializable {
    private String fabricante="fiat";
    public CarBean() {
    }
    public String getFabricante() {
        return fabricante;
    }
    public void setFabricante(String fabricante) {
        this.fabricante=fabricante;
    }
}
