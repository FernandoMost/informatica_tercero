// Comando de compilación: javac -cp /usr/share/java/servlet-api-3.1.jar servlet.java
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class servlet extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String nome=req.getParameter("nome");req.setAttribute("nome",nome);
		String chave=req.getParameter("chave");req.setAttribute("chave",chave);
		RequestDispatcher  vista=req.getRequestDispatcher("index.jsp");
		vista.forward(req,res);
	}
} 
